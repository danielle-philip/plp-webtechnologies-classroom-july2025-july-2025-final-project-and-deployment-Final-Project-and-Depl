
document.addEventListener('DOMContentLoaded', () => {
  const toggleBtn = document.getElementById('menu-toggle');
  const navLinks = document.querySelectorAll('#navbar a');
  toggleBtn.addEventListener('click', () => {
    navLinks.forEach(link => {
      link.style.display = link.style.display === 'block' ? 'none' : 'block';
    });
  });

  const fadeElements = document.querySelectorAll('.fade-in');
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if(entry.isIntersecting){
        entry.target.classList.add('visible');
      }
    });
  }, {threshold:0.1});
  fadeElements.forEach(el => observer.observe(el));
});
